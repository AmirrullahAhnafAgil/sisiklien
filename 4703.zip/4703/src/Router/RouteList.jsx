import { createBrowserRouter } from "react-router-dom";

import Login from "../Pages/Auth/Login.jsx"
import Register from "../Pages/Auth/Register.jsx";
import AdminLayout from "../Layouts/AdminLayout.jsx";
import Dashboard from "../Pages/Admin/Dashboard.jsx";
import Produk from "../Pages/Admin/Produk.jsx";

const RouteList = createBrowserRouter([
    {
        path: "/",
        element: <Login />
    },
    {
        path: "/register",
        element: <Register />
    },
    {
        path: "/admin",
        element: <AdminLayout />,
        children: [
            {
                index: true,
                element: <Dashboard />
            },
            {
                path: "produk",
                element: <Produk />
            },
        ]
    }
]);

export default RouteList;