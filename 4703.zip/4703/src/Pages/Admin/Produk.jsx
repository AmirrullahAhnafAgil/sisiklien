import axios from "axios";
import { useEffect, useState } from "react";

const Produk = () => {
  const [data, setData] = useState([]); // untuk data dari api
  const [error, setError] = useState(null); // pesan error
  const [form, setForm] = useState({ title: '', body: ''}); // untuk isi data form
  
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('https://jsonplaceholder.typicode.com/posts', form);
      setData([...data, {...form, id:response.data.id}]);
      setForm({ title: '', body: '' });
    } catch (error){
      setError('error niiihh');
    }
  }

  const handleChange = (e) => {
    e.preventDefault();
    const { name, value } = e.target;
    setForm({ ...form, [name]:value});
  }
  
  useEffect(() => {
    const ambilData = async () => {
      try {
        const response = await axios.get('https://jsonplaceholder.typicode.com/posts');
        setData(response.data.slice(0, 10));
      } catch (error){
        setError('Data gagal diambil, hehe');
      }
    };

    ambilData();

    console.log(data);
  }, []);


  return (
    <div>
        <table className="min-w-full table-auto">
              <thead>
            <tr className="bg-gray-200">
              <th className="px-4 py-2">Id</th>
              <th className="px-4 py-2">Judul</th>
              <th className="px-4 py-2">Deskripsi</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item) => (
              <tr>
                <td>{item.id}</td>
                <td>{item.title}</td>
                <td>{item.body}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <form onSubmit={handleSubmit}>
          <div>
            <label>Judul</label>
            <input 
              type="text"
              name="title"
              value={form.title}
              onChange={handleChange}
              required  
            />
          </div>
          <div>
            <label>Deskripsi</label>
            <textarea 
              name="body"
              value={form.body}
              onChange={handleChange}
              required  
            />
          </div>
          <button type="submit">Simpan</button>
        </form>
    </div>
    );
};

export default Produk;