const Register = () => {
    return (
        <div>
            Halaman Register
        </div>
    )
}

export default Register;