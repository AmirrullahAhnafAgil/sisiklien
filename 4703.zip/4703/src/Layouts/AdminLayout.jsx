import { Outlet } from "react-router-dom";

const AdminLayout = () => {
    return (
      <div className="flex flex-row min-h-screen">
        {/* Sidebar */}
        <aside className="w-64 bg-indigo-900 text-white">
          <div className="p-4">
            <h1 className="text-2xl font-bold">Admin Panel</h1>
            <nav className="mt-4">
              <ul>
                <li className="py-2 px-4 hover:bg-indigo-800">
                  <a href="/admin">Dashboard</a>
                </li>
                <li className="py-2 px-4 hover:bg-indigo-800">
                  <a href="/admin/produk">Mahasiswa</a>
                </li>
                <li className="py-2 px-4 hover:bg-indigo-800">
                  <a href="#">Settings</a>
                </li>
              </ul>
            </nav>
          </div>
        </aside>
  
        {/* Content Area */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <header className="bg-white shadow p-4">
            <div className="flex justify-end items-center">
              <button className="bg-blue-500 text-white px-4 py-2 rounded">Log Out</button>
            </div>
          </header>
  
          {/* Main Content */}
          <main className="flex-grow p-4 bg-blue-50">
            <Outlet />
          </main>
  
          {/* Footer */}
          <footer className="bg-indigo-900 text-white p-4 text-center">
            &copy; 2024 Admin Dashboard
          </footer>
        </div>
      </div>
    );
  };

export default AdminLayout;